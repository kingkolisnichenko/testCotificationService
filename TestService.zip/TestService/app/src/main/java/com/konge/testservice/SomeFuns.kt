package com.konge.testservice

import android.app.ActivityManager
import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences
import com.konge.testservice.Constants.MAX_DATA_SIZE
import com.konge.testservice.Constants.MAX_PACKET_SIZE
import com.konge.testservice.Constants.MESSAGE_POSTAMBLE
import com.konge.testservice.Constants.MESSAGE_PREAMBLE
import com.konge.testservice.Constants.MESSAGE_TERMINATOR
import com.konge.testservice.Constants.PREFERENCE_FILE_KEY
import java.nio.BufferOverflowException
import java.nio.ByteBuffer

var sequenceNumber = 32
    get() {
        if (field > 127) field = 32
        return field++
    }

lateinit var sharedpreferences: SharedPreferences

fun initSharedPrefs(context: Context){
    sharedpreferences = context.getSharedPreferences(PREFERENCE_FILE_KEY, MODE_PRIVATE)
}

fun savePrefs(key: String, data: String){
    sharedpreferences.edit().putString(key, data).apply()
}

fun restorePrefs(key: String): String {
    var getString = ""
    if (sharedpreferences.contains(key)) {
        getString = sharedpreferences.getString(key, "").toString()
    }
    return getString
}

//  TODO Проверяет запущена ли служба
fun isMyServiceRunning(context: Context, mClass: Class<MyTestService>): Boolean{

    val manager: ActivityManager = context.getSystemService(
        Context.ACTIVITY_SERVICE
    ) as ActivityManager

    for (service: ActivityManager.RunningServiceInfo in
    manager.getRunningServices(Integer.MAX_VALUE)){

        if (mClass.name.equals(service.service.className)){
            return true
        }
    }
    return false
}

//<01><LEN><SEQ><CMD><DATA><05><BCC><03>
//@Throws(CommandSyntaxException::class)
fun wrapCommand(code: Int, data: String): ByteArray {
    val buffer = try {
        ByteBuffer.allocate(MAX_PACKET_SIZE).apply {
            position(1)//shift position for preamble
            val byteData = data.toByteArray()
            if (byteData.size > MAX_DATA_SIZE) throw Exception("Command data size is out of limit: ${byteData.size}.")
            put(add30H(byteData.size + 10 + 32))//LEN
            put(sequenceNumber.toByte())
            put(add30H(code))//CMD
            put(byteData)//DATA
            put(MESSAGE_POSTAMBLE)
            put(add30H(array().sum()))//BCC
            put(MESSAGE_TERMINATOR)
            put(0, MESSAGE_PREAMBLE)
        }
    } catch (e: BufferOverflowException) {
        throw Exception(e.message)
    } catch (e: IndexOutOfBoundsException) {
        throw Exception(e.message)
    }
    val result = ByteArray(buffer.position())
    buffer.rewind()
    buffer.get(result)
    return result
}

fun subtract30H(number: ByteArray): Int {
    return number.map {
            (it - 0x30).toString(16)
        }.joinToString(separator = "").toInt(16)
}

fun add30H(number: Int): ByteArray {
    return String.format("%04x", number)
        .map {
            (it.toString().toInt(16) + 0x30).toByte()
        }.toByteArray()
}
