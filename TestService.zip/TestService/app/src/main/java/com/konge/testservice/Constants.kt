package com.konge.testservice

object Constants {

    // Уведомление
    const val CHANNEL_ID = "MyService"
    const val NOTIFICATION_ID = 666

    // Действия службы
    const val START_SERVICE = "START_SERVICE"
    const val STOP_SERVICE = "STOP_SERVICE"
    const val DO_COMMAND = "DO_COMMAND"
    const val CHECK_CONNECTION  = "CHECK_CONNECTION"

    // Сохранение настроек
    const val PREFERENCE_FILE_KEY = "DatecsDriverPrefs"
    const val APP_PREFERENCES_BT_ADDRESS = "APP_PREFERENCES_BT_ADDRESS"
    const val DEVICE_TYPE = "DEVICE_TYPE"

    // Подключение и отправка комманд
    const val MESSAGE_PREAMBLE: Byte = 1
    const val MESSAGE_SEPARATOR: Byte = 4
    const val MESSAGE_POSTAMBLE: Byte = 5
    const val MESSAGE_TERMINATOR: Byte = 3
    const val MAX_PACKET_SIZE = 224
    const val MAX_DATA_SIZE = 213
}