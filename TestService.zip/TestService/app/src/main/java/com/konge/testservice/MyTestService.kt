package com.konge.testservice

import android.app.*
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.*
import android.util.Log
import android.widget.Toast
import com.konge.testservice.Constants.CHANNEL_ID
import com.konge.testservice.Constants.CHECK_CONNECTION
import com.konge.testservice.Constants.DO_COMMAND
import com.konge.testservice.Constants.NOTIFICATION_ID
import com.konge.testservice.Constants.START_SERVICE
import com.konge.testservice.Constants.STOP_SERVICE
import java.lang.Exception
import kotlin.concurrent.thread


class MyTestService: Service()
{
    val TAG = "MyService"
    private lateinit var myConnection: Connection
    private lateinit var mHandler: Handler
    private lateinit var mythread: Thread

    // Стандартные
    override fun onBind(p0: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        showLog("onCreate")

        initSharedPrefs(this)
        var address = restorePrefs(Constants.APP_PREFERENCES_BT_ADDRESS)
        address = address.substring(address.length-17, address.length)
        if (address != "") {

            myConnection = Connection(address)
        }

        createNotificationChannel()

        initHandler()

    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        showLog("onStartCommand")

        when(intent!!.action) {
            START_SERVICE -> startThisService()
            STOP_SERVICE -> stopSelf()
            DO_COMMAND -> doSomething(intent)
            CHECK_CONNECTION -> getConnectionStatus()
        }

        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        super.onDestroy()

        if(myConnection.isConnected())
        {
            myConnection.disconnect()
            Toast.makeText(this, "Устройство отключено", Toast.LENGTH_SHORT).show()
        }

        showLog("onDestroy")
    }

    // Что-то делаем
    private fun doSomething(intent: Intent){

        myConnection.sendCommand(
            wrapCommand(
                intent.getIntExtra("Command",0),
                intent.getStringExtra("Data").toString()
            ),
            3_000,
            3
        )

    }

    //Создание подключения
    private fun createConnection(){

            if(!BluetoothAdapter.getDefaultAdapter().isEnabled){
                showMessage("Bluetooth выключен, служба остановлена")
                stopSelf()
            }else {
                Thread(
                    Runnable {
                        var result = myConnection.connectToDevice()
                        if (result) {
                            showMessage("Подключено")
                        } else {
                            showMessage("Не удалось подключиться, служба остановлена")
                            stopSelf()
                        }
                    }
                ).start()
            }

    }

    // Служебные
    private fun startThisService(){

        showNotification()

        createConnection()

    }

    private fun initHandler() {
        mHandler = object: Handler(Looper.getMainLooper()){
            override fun handleMessage(msg: Message) {
                super.handleMessage(msg)

                if(msg.data["Exit"] == true){
//                    setResult(RESULT_OK, ansIntent)
//                    mythread.interrupt()
//                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//                        finishAndRemoveTask()
                }

                if(msg.data["Msg"] != ""){
                    Toast.makeText(applicationContext, msg.data["Msg"].toString(), Toast.LENGTH_SHORT).show()
                }
            }

        }
    }

    private fun showMessage(msg: String = "", exit: Boolean = false){
        var message: Message = mHandler.obtainMessage()
        val bundle = Bundle()
        bundle.putString("Msg", msg)
        bundle.putBoolean("Exit", exit)
        message.data = bundle
        mHandler.sendMessage(message)
    }

    private fun createNotificationChannel(){

        val serviceChannel = NotificationChannel(CHANNEL_ID, "My service", NotificationManager.IMPORTANCE_HIGH)

        val manager = getSystemService(NotificationManager::class.java)

        manager.createNotificationChannel(serviceChannel)
    }

    private fun getConnectionStatus(){
        if (myConnection.isConnected()) {
            Toast.makeText(this, "Устройство подключено", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showNotification() {
        val notificationIntent = Intent(this, MyTestService::class.java)

        val pendingIntent = PendingIntent.getActivity(this,0, notificationIntent,0)

        val notification = Notification
            .Builder(this, CHANNEL_ID)
            .setContentText("Service datecs driver")
            .setContentTitle("Driver")
            .setSmallIcon(R.drawable.ic_notifacation_datecs_driver)
            .setContentIntent(pendingIntent)
            .build()

        startForeground(NOTIFICATION_ID, notification)

    }

    private fun showLog(msg: String){
        Log.d(TAG, msg)
    }

}