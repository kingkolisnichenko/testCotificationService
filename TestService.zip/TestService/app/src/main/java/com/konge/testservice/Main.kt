package com.konge.testservice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.os.Environment.getExternalStoragePublicDirectory
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.konge.testservice.Constants.APP_PREFERENCES_BT_ADDRESS
import com.konge.testservice.Constants.CHECK_CONNECTION
import com.konge.testservice.Constants.DEVICE_TYPE
import com.konge.testservice.Constants.DO_COMMAND
import com.konge.testservice.Constants.START_SERVICE
import com.konge.testservice.Constants.STOP_SERVICE
import com.konge.testservice.databinding.ActivityMainBinding
import java.io.File
import java.io.FileWriter
import kotlin.concurrent.thread

class Main: AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initSharedPrefs(this)

        findViewById<Button>(R.id.btnStart).setOnClickListener(this)
        findViewById<Button>(R.id.btnStop).setOnClickListener(this)
        findViewById<Button>(R.id.btnSend).setOnClickListener(this)
        findViewById<Button>(R.id.btnSelectDevice).setOnClickListener(this)
        findViewById<Button>(R.id.btnStatus).setOnClickListener(this)

        var arrTypes = arrayOf("Datecs", "Tremol")
        findViewById<Spinner>(R.id.spType).adapter = ArrayAdapter(
            this,
            R.layout.support_simple_spinner_dropdown_item,
            arrTypes
        )

        findViewById<Spinner>(R.id.spType).setSelection(
            arrTypes.indexOf(restorePrefs(DEVICE_TYPE))
        )

        findViewById<TextView>(R.id.tvDeviceAddress).text = restorePrefs(APP_PREFERENCES_BT_ADDRESS)
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.btnStart -> start()
            R.id.btnStop -> stop()
            R.id.btnSend -> send()
            R.id.btnSelectDevice -> selectDevice()
            R.id.btnStatus -> getConnectionStatus()
        }
    }

    override fun onResume() {
        super.onResume()
        initSharedPrefs(this)
    }

    override fun onPause() {
        super.onPause()
        savePrefs(
            DEVICE_TYPE,
            findViewById<Spinner>(R.id.spType).selectedItem.toString()
        )
        savePrefs(
            APP_PREFERENCES_BT_ADDRESS,
            findViewById<TextView>(R.id.tvDeviceAddress).text.toString()
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK && data!!.hasExtra("ADDRESS")){
            var address = data!!.getStringExtra("ADDRESS").toString()
            findViewById<TextView>(R.id.tvDeviceAddress).text = address

            savePrefs(
                APP_PREFERENCES_BT_ADDRESS,
                address
            )
        }

    }

    private fun getConnectionStatus(){
        val intent = Intent(this, MyTestService::class.java)
        intent.action = CHECK_CONNECTION
        if (isMyServiceRunning(this, MyTestService::class.java)){
            startService(intent)
        }else{
            Toast.makeText(this, "Служба не запущена", Toast.LENGTH_SHORT).show()
        }
    }

    private fun selectDevice() {
        val intent = Intent(this, SelectDeviceActivity::class.java)
        startActivityForResult(intent, 1)
    }

    private fun send(){
        val intent = Intent(this, MyTestService::class.java)
        intent.action = DO_COMMAND
        intent.putExtra("Command", 69)
        intent.putExtra("Data", "X\t")

        if (isMyServiceRunning(this, MyTestService::class.java)){
            startService(intent)
        }else{
            Toast.makeText(this, "Служба не запущена", Toast.LENGTH_SHORT).show()
        }

    }

    private fun start(){

        if (isMyServiceRunning(this, MyTestService::class.java)){
            Toast.makeText(this, "Служба уже работает", Toast.LENGTH_SHORT).show()
        }else{
            startService(
                Intent(this, MyTestService::class.java).setAction(START_SERVICE)
            )

            Toast.makeText(this, "Служба запущена", Toast.LENGTH_SHORT).show()
        }

    }

    private fun stop(){

        if (isMyServiceRunning(this, MyTestService::class.java)){
            startService(
                Intent(this, MyTestService::class.java).setAction(STOP_SERVICE)
            )

            Toast.makeText(this, "Служба остановлена", Toast.LENGTH_SHORT).show()
        }else{
            Toast.makeText(this, "Служба не запущена", Toast.LENGTH_SHORT).show()
        }

    }

}