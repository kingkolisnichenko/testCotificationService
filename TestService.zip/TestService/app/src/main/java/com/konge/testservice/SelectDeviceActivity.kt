package com.konge.testservice

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class SelectDeviceActivity: AppCompatActivity() {

    private var mBluetoothAdapter: BluetoothAdapter? = null
    private lateinit var mPariedDivaces: Set<BluetoothDevice>
    private val REQUEST_ENABLE_BLUETOOTH = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_device)
//        setSupportActionBar(findViewById<Toolbar>(R.id.toolbarSelect).also {
//            title = "Выбор устройства"
//        })

        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (mBluetoothAdapter == null){
            Toast.makeText(this,"Устройство не поддерживает bluetooth", Toast.LENGTH_SHORT).show()
            return
        }

        if (!mBluetoothAdapter!!.isEnabled){
            val enableBluetoothIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBluetoothIntent, REQUEST_ENABLE_BLUETOOTH)
        }

        mPariedDivaces = mBluetoothAdapter!!.bondedDevices
        val list: ArrayList<String> = ArrayList()

        if(mPariedDivaces.isNotEmpty()){
            for (device: BluetoothDevice in mPariedDivaces){
                list.add("${device.name} \n${device.address}")
                Log.i("Device", "" + device)
            }
        } else if(mPariedDivaces.isEmpty()){
            Toast.makeText(this,"Не найдено Bluetooth устройств", Toast.LENGTH_SHORT).show()
        }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, list)
        findViewById<ListView>(R.id.selest_device_List).adapter = adapter

        findViewById<ListView>(R.id.selest_device_List).onItemClickListener = AdapterView.OnItemClickListener{ _, _, position, _ ->

            val address: String = list[position]

            val intent: Intent = Intent().putExtra("ADDRESS", address)
            setResult(RESULT_OK, intent)
            finish()
        }
    }
}