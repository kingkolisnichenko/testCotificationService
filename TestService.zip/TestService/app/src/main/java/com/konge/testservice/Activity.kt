package com.konge.testservice

import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.konge.testservice.databinding.ActivityMainBinding
import org.json.JSONObject

class Activity: AppCompatActivity() {
    private lateinit var ansIntent: Intent

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        initSharedPrefs(this)
        ansIntent = Intent()

        var intentFrom1C = intent.getStringExtra("INTENT_1C") ?:""

        if(intentFrom1C == ""){
            ansIntent.putExtra("MESSAGE", "Нет данных для обработки")
            ansIntent.putExtra("RESULT", false)
            setResult(RESULT_OK, ansIntent)
            this.finish()
        }

        if(!BluetoothAdapter.getDefaultAdapter().isEnabled){
            ansIntent.putExtra("MESSAGE", "Bluetooth выключен!")
            ansIntent.putExtra("RESULT", false)
            setResult(RESULT_OK, ansIntent)
            this.finish()
        }

        if(!isMyServiceRunning(this, MyTestService::class.java)){
            startService(
                Intent(this, MyTestService::class.java).setAction(Constants.START_SERVICE)
            )
        }

        val data = JSONObject(intentFrom1C)



        val intent = Intent(this, MyTestService::class.java)
        intent.action = Constants.DO_COMMAND
        intent.putExtra("Command", data["CMD"].toString().toInt())
        intent.putExtra("Data", data["DATA"].toString()+"\t")

        startService(intent)
//        var ansIntent = Intent()
//        ansIntent.putExtra("Result", "Вроде работает")
//        setResult(RESULT_OK, ansIntent)
//        this.finish()
    }
}