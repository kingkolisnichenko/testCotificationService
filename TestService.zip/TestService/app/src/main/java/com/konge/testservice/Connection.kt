package com.konge.testservice

import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.util.Log
import android.widget.Toast
import com.konge.testservice.Constants.MAX_PACKET_SIZE
import com.konge.testservice.Constants.MESSAGE_TERMINATOR
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.util.*

class Connection(var mDeviceAddress: String) {
    protected var mBluetoothAdapter: BluetoothAdapter? = null
    protected var mBluetoothSocket: BluetoothSocket? = null
    protected var mBluetoothDevice: BluetoothDevice? = null
    protected var mOutputStream: OutputStream? = null
    protected var mInputStream: InputStream? = null
    protected val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    protected var waitTillAnswer = true

    private val RETRY_TIMEOUT = 500L
    private val RESPONSE_TIME = 60L
    val NAK: Byte = 0x15
    val SYN: Byte = 0x16

    init {
        Log.d("connection", "init")
    }

    fun connectToDevice(): Boolean{

        mBluetoothDevice = getBluetoothDevice()

        mBluetoothSocket = mBluetoothDevice?.createRfcommSocketToServiceRecord(uuid)

        if (mBluetoothDevice == null) {
            return false
        }

        mBluetoothAdapter!!.cancelDiscovery()
        try {
            Thread.sleep(1_000)
            mBluetoothSocket?.connect()
        }catch (e: Exception){
            Log.d("connection", e.message.toString())
        }

        mOutputStream = mBluetoothSocket?.getOutputStream()
        mInputStream = mBluetoothSocket?.getInputStream()

        if (mBluetoothSocket?.isConnected == true) {
            Log.d("connection", "Успешно подключено!")
            return true
        }
        return false
    }

    fun getBluetoothDevice(): BluetoothDevice? {
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter()

        if (mBluetoothAdapter == null) throw Exception("Устройство не подджерживает Bluetooth")

        if (!mBluetoothAdapter!!.isEnabled) throw Exception("Bluetooth выключен")

        val pairedDevices = mBluetoothAdapter!!.bondedDevices

        Log.d("connection", "Known Devices List: " + Arrays.toString(pairedDevices.toTypedArray()))

        if (pairedDevices.isNotEmpty()) {
            Log.d("connection", "Device is found in paired")

            for (device in pairedDevices) {
                if (device.address == mDeviceAddress) {
                    return device
                }
            }
        }

        return null
    }

    fun isConnected():Boolean{
        return mBluetoothSocket != null && mBluetoothSocket!!.isConnected && mOutputStream != null && mInputStream != null
    }


//    @Throws(ConnectionException::class, MessageException::class)
    fun sendCommand(command: ByteArray, timeout: Long, rcount: Int): ByteArray {
        Log.d("command", "CommandBytes: ${command.contentToString()}")
        val response = ByteBuffer.allocate(MAX_PACKET_SIZE)
        waitTillAnswer = timeout != 0L
        for (t in 0 until rcount) {
            Log.d("command", "~~~~~~~~~~ READ_ANSWER TRY: " + (t + 1) + " ~~~~~~~~~~")
            try {
                if (mOutputStream != null) {
                    mOutputStream?.write(command)
                } else {
                    Log.d("command", "!!!!!!!!!! OutputStream Unavailable !!!!!!!!!!")
                    throw Exception("OutputStream Unavailable")
                }
                val buffer = ByteBuffer.allocate(MAX_PACKET_SIZE)
                Thread.sleep(RESPONSE_TIME)// wait before reading answer
                var end = System.currentTimeMillis() + timeout
                while (waitTillAnswer && end > System.currentTimeMillis()) {
//                    Log.d("connection", "Now: " + System.currentTimeMillis() + " End: " + end + " Timeout: " + timeout);
                    var bytesAvailable = mInputStream!!.available()
                    if (bytesAvailable > 0) {
//                        Log.d("command", "initial bytesAvailable: $bytesAvailable")
                        do {
                            end += RESPONSE_TIME
                            Thread.sleep(RESPONSE_TIME)
                            bytesAvailable = mInputStream!!.available()
                            Log.d("command", "bytesAvailable: $bytesAvailable")
                        } while (mInputStream!!.available() > bytesAvailable)
                        val receivedBytes = ByteArray(bytesAvailable)
                        mInputStream?.read(receivedBytes)
//                        flushOutputStream()
                        Log.d("command", "receivedBytes: " + receivedBytes.contentToString())
                        for (i in 0 until bytesAvailable) {
                            val packByte = receivedBytes[i]
                            if (packByte == SYN) continue
                            if (packByte == NAK) throw Exception(command.contentToString())
                            buffer.put(packByte)
                            if (packByte == MESSAGE_TERMINATOR) {
                                waitTillAnswer = false
                                response.put(buffer.array())
                                val restBytes = mInputStream?.available()
                                Log.d("command", "More bytes available: $restBytes")
                                Log.d("command", "########## ANSWER READ ON TRY: " + (t + 1) + "##########")
                                //return Response(response.array(), command)
                                return response.array()

                            }

                        }
                    }
                }
//                flushOutputStream()
            } catch (e: IOException) {
                e.printStackTrace()
                flushOutputStream()
                disconnect()
                Log.d("command", "sendCommand-IOException: " + e.message)
                throw Exception(e.message)
            } catch (e: InterruptedException) {
                e.printStackTrace()
                flushOutputStream()
                disconnect()
                Log.d("command", "sendCommand-InterruptedException: " + e.message)
                throw Exception(e.message)
            }
            Thread.sleep(RETRY_TIMEOUT)//wait before retry
        }
        flushOutputStream()
        Log.d("command", "!!!!!!!!!! Answer read timeout !!!!!!!!!!")
        throw Exception("Command: $command")
    }

    internal fun flushOutputStream() {
        try {
            if (mOutputStream != null) {
                mOutputStream!!.flush()
                Log.d("command", "OutputStream Flush")
            }
        } catch (e: IOException) {
            Log.d("command", "Could not Flush OutputStream")
            e.printStackTrace()
        }
    }

    fun disconnect() {
        if (mOutputStream != null) {
            mOutputStream!!.flush()
            mOutputStream!!.close()
            mOutputStream = null
        }
        if (mInputStream != null) {
            mInputStream!!.close()
            mInputStream = null
        }
        if (mBluetoothSocket != null && mBluetoothSocket!!.isConnected) {
            mBluetoothSocket!!.close()
            mBluetoothSocket = null
        }
        Log.d("connection", "Close Connection")
    }
}